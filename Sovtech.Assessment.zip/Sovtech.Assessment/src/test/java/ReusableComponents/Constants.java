package ReusableComponents;

public class Constants {
	
	public static final String browser="webdriver.chrome.driver";
	public static final String browserlocation="C:\\Selenium_Workspace\\New_Selenium_Workspace\\Sovtech.Assessment\\Drivers\\chromedriver.exe";
	public static final String link="https://www.sovtech.co.za/contact-us/";
	
	public static final String excelLocation = "C:\\Selenium_Workspace\\New_Selenium_Workspace\\Sovtech.Assessment\\TestData\\";
	public static final String excelFilename="TestData.xlsx";
	public static final String ExcelSheetname = "PositiveScenario";
	public static final String excelSheetname2 = "NegativeScenario";
	
}
